
  # LevaAqui Marketplace Platform

  This is a code bundle for LevaAqui Marketplace Platform. The original project is available at https://www.figma.com/design/1pS5EfJzM3wKgYllwRZq2z/LevaAqui-Marketplace-Platform.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  