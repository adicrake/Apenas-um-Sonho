import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { X, Plus, Edit2, Trash2, Save, Users, ShoppingBag, ArrowLeft, Lock } from 'lucide-react';
import { Vendor, Product } from '../App';

interface AdminPanelProps {
  onBack: () => void;
}

export function AdminPanel({ onBack }: AdminPanelProps) {
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [password, setPassword] = useState('');
  const [activeTab, setActiveTab] = useState<'vendors' | 'products'>('vendors');
  const [vendors, setVendors] = useState<Vendor[]>([]);
  const [products, setProducts] = useState<Product[]>([]);
  const [showVendorForm, setShowVendorForm] = useState(false);
  const [showProductForm, setShowProductForm] = useState(false);
  const [editingVendor, setEditingVendor] = useState<Vendor | null>(null);
  const [editingProduct, setEditingProduct] = useState<Product | null>(null);

  // Load data from localStorage
  useEffect(() => {
    const savedVendors = localStorage.getItem('levaaqui_vendors');
    const savedProducts = localStorage.getItem('levaaqui_products');
    
    if (savedVendors) setVendors(JSON.parse(savedVendors));
    if (savedProducts) setProducts(JSON.parse(savedProducts));
  }, []);

  // Save vendors to localStorage
  const saveVendors = (newVendors: Vendor[]) => {
    setVendors(newVendors);
    localStorage.setItem('levaaqui_vendors', JSON.stringify(newVendors));
  };

  // Save products to localStorage
  const saveProducts = (newProducts: Product[]) => {
    setProducts(newProducts);
    localStorage.setItem('levaaqui_products', JSON.stringify(newProducts));
  };

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    // Simple password check - in production use proper authentication
    if (password === 'admin123') {
      setIsAuthenticated(true);
    } else {
      alert('Senha incorreta!');
    }
  };

  if (!isAuthenticated) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-600 via-blue-500 to-yellow-400 flex items-center justify-center px-4">
        <motion.div
          className="bg-white rounded-2xl shadow-2xl p-8 max-w-md w-full"
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.3 }}
        >
          <div className="text-center mb-8">
            <div className="bg-blue-100 w-20 h-20 rounded-full flex items-center justify-center mx-auto mb-4">
              <Lock className="text-blue-600" size={40} />
            </div>
            <h1 className="text-3xl font-bold text-gray-900 mb-2">Painel Admin</h1>
            <p className="text-gray-600">Digite a senha para acessar</p>
          </div>

          <form onSubmit={handleLogin}>
            <input
              type="password"
              placeholder="Senha de administrador"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              className="w-full px-4 py-3 rounded-lg border-2 border-gray-200 focus:border-blue-500 focus:outline-none mb-4"
            />
            <button
              type="submit"
              className="w-full bg-gradient-to-r from-blue-600 to-blue-500 text-white py-3 rounded-lg font-semibold hover:from-blue-700 hover:to-blue-600 transition-all"
            >
              Entrar
            </button>
            <button
              type="button"
              onClick={onBack}
              className="w-full mt-3 text-gray-600 hover:text-gray-800 font-medium"
            >
              Voltar ao Site
            </button>
          </form>

          <div className="mt-6 p-4 bg-blue-50 rounded-lg">
            <p className="text-sm text-gray-600 text-center">
              <strong>Senha padrão:</strong> admin123
            </p>
          </div>
        </motion.div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-white shadow-md">
        <div className="max-w-7xl mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <button
                onClick={onBack}
                className="flex items-center gap-2 text-gray-600 hover:text-gray-800 font-semibold"
              >
                <ArrowLeft size={20} />
                Voltar
              </button>
              <h1 className="text-2xl font-bold text-gray-900">Painel de Controle</h1>
            </div>
            <button
              onClick={() => setIsAuthenticated(false)}
              className="text-red-600 hover:text-red-700 font-semibold"
            >
              Sair
            </button>
          </div>
        </div>
      </div>

      {/* Tab Navigation */}
      <div className="bg-white border-b border-gray-200">
        <div className="max-w-7xl mx-auto px-4">
          <div className="flex gap-2">
            <button
              onClick={() => setActiveTab('vendors')}
              className={`relative px-6 py-4 font-semibold transition-colors flex items-center gap-2 ${
                activeTab === 'vendors' ? 'text-blue-600' : 'text-gray-600 hover:text-gray-800'
              }`}
            >
              <Users size={20} />
              Vendedores ({vendors.length})
              {activeTab === 'vendors' && (
                <motion.div
                  className="absolute bottom-0 left-0 right-0 h-1 bg-blue-600"
                  layoutId="adminTab"
                />
              )}
            </button>
            <button
              onClick={() => setActiveTab('products')}
              className={`relative px-6 py-4 font-semibold transition-colors flex items-center gap-2 ${
                activeTab === 'products' ? 'text-blue-600' : 'text-gray-600 hover:text-gray-800'
              }`}
            >
              <ShoppingBag size={20} />
              Produtos ({products.length})
              {activeTab === 'products' && (
                <motion.div
                  className="absolute bottom-0 left-0 right-0 h-1 bg-blue-600"
                  layoutId="adminTab"
                />
              )}
            </button>
          </div>
        </div>
      </div>

      {/* Content */}
      <div className="max-w-7xl mx-auto px-4 py-8">
        {activeTab === 'vendors' && (
          <VendorsTab
            vendors={vendors}
            onSave={saveVendors}
            showForm={showVendorForm}
            setShowForm={setShowVendorForm}
            editingVendor={editingVendor}
            setEditingVendor={setEditingVendor}
          />
        )}

        {activeTab === 'products' && (
          <ProductsTab
            products={products}
            vendors={vendors}
            onSave={saveProducts}
            showForm={showProductForm}
            setShowForm={setShowProductForm}
            editingProduct={editingProduct}
            setEditingProduct={setEditingProduct}
          />
        )}
      </div>
    </div>
  );
}

// Vendors Tab Component
interface VendorsTabProps {
  vendors: Vendor[];
  onSave: (vendors: Vendor[]) => void;
  showForm: boolean;
  setShowForm: (show: boolean) => void;
  editingVendor: Vendor | null;
  setEditingVendor: (vendor: Vendor | null) => void;
}

function VendorsTab({ vendors, onSave, showForm, setShowForm, editingVendor, setEditingVendor }: VendorsTabProps) {
  const handleDelete = (id: string) => {
    if (confirm('Tem certeza que deseja deletar este vendedor?')) {
      onSave(vendors.filter(v => v.id !== id));
    }
  };

  const handleEdit = (vendor: Vendor) => {
    setEditingVendor(vendor);
    setShowForm(true);
  };

  return (
    <div>
      <div className="flex justify-between items-center mb-6">
        <h2 className="text-2xl font-bold text-gray-900">Gerenciar Vendedores</h2>
        <button
          onClick={() => {
            setEditingVendor(null);
            setShowForm(true);
          }}
          className="flex items-center gap-2 bg-blue-600 text-white px-6 py-3 rounded-lg font-semibold hover:bg-blue-700 transition-colors"
        >
          <Plus size={20} />
          Novo Vendedor
        </button>
      </div>

      {/* Vendor List */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 mb-8">
        {vendors.map((vendor) => (
          <div key={vendor.id} className="bg-white rounded-lg shadow-md p-6">
            <div className="flex items-start gap-4 mb-4">
              <img
                src={vendor.photo}
                alt={vendor.name}
                className="w-16 h-16 rounded-full object-cover"
              />
              <div className="flex-1">
                <h3 className="font-bold text-gray-900">{vendor.name}</h3>
                <p className="text-sm text-gray-600">{vendor.classroom}</p>
                <p className="text-sm text-gray-600">{vendor.schedule.start} - {vendor.schedule.end}</p>
              </div>
            </div>
            <div className="flex gap-2">
              <button
                onClick={() => handleEdit(vendor)}
                className="flex-1 flex items-center justify-center gap-2 bg-yellow-500 text-white px-4 py-2 rounded-lg hover:bg-yellow-600 transition-colors"
              >
                <Edit2 size={16} />
                Editar
              </button>
              <button
                onClick={() => handleDelete(vendor.id)}
                className="flex-1 flex items-center justify-center gap-2 bg-red-500 text-white px-4 py-2 rounded-lg hover:bg-red-600 transition-colors"
              >
                <Trash2 size={16} />
                Deletar
              </button>
            </div>
          </div>
        ))}
      </div>

      {/* Vendor Form Modal */}
      <AnimatePresence>
        {showForm && (
          <VendorFormModal
            vendor={editingVendor}
            vendors={vendors}
            onSave={onSave}
            onClose={() => {
              setShowForm(false);
              setEditingVendor(null);
            }}
          />
        )}
      </AnimatePresence>
    </div>
  );
}

// Products Tab Component
interface ProductsTabProps {
  products: Product[];
  vendors: Vendor[];
  onSave: (products: Product[]) => void;
  showForm: boolean;
  setShowForm: (show: boolean) => void;
  editingProduct: Product | null;
  setEditingProduct: (product: Product | null) => void;
}

function ProductsTab({ products, vendors, onSave, showForm, setShowForm, editingProduct, setEditingProduct }: ProductsTabProps) {
  const handleDelete = (id: string) => {
    if (confirm('Tem certeza que deseja deletar este produto?')) {
      onSave(products.filter(p => p.id !== id));
    }
  };

  const handleEdit = (product: Product) => {
    setEditingProduct(product);
    setShowForm(true);
  };

  return (
    <div>
      <div className="flex justify-between items-center mb-6">
        <h2 className="text-2xl font-bold text-gray-900">Gerenciar Produtos</h2>
        <button
          onClick={() => {
            setEditingProduct(null);
            setShowForm(true);
          }}
          className="flex items-center gap-2 bg-blue-600 text-white px-6 py-3 rounded-lg font-semibold hover:bg-blue-700 transition-colors"
        >
          <Plus size={20} />
          Novo Produto
        </button>
      </div>

      {/* Product List */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 mb-8">
        {products.map((product) => (
          <div key={product.id} className="bg-white rounded-lg shadow-md overflow-hidden">
            <img
              src={product.photos[0]}
              alt={product.name}
              className="w-full h-40 object-cover"
            />
            <div className="p-4">
              <h3 className="font-bold text-gray-900 mb-1">{product.name}</h3>
              <p className="text-xl font-bold text-blue-600 mb-2">{product.price} Kz</p>
              <p className="text-sm text-gray-600 mb-3">
                Vendedor: {product.vendor.name}
              </p>
              <div className="flex gap-2">
                <button
                  onClick={() => handleEdit(product)}
                  className="flex-1 flex items-center justify-center gap-2 bg-yellow-500 text-white px-4 py-2 rounded-lg hover:bg-yellow-600 transition-colors"
                >
                  <Edit2 size={16} />
                  Editar
                </button>
                <button
                  onClick={() => handleDelete(product.id)}
                  className="flex-1 flex items-center justify-center gap-2 bg-red-500 text-white px-4 py-2 rounded-lg hover:bg-red-600 transition-colors"
                >
                  <Trash2 size={16} />
                  Deletar
                </button>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Product Form Modal */}
      <AnimatePresence>
        {showForm && (
          <ProductFormModal
            product={editingProduct}
            products={products}
            vendors={vendors}
            onSave={onSave}
            onClose={() => {
              setShowForm(false);
              setEditingProduct(null);
            }}
          />
        )}
      </AnimatePresence>
    </div>
  );
}

// Vendor Form Modal
interface VendorFormModalProps {
  vendor: Vendor | null;
  vendors: Vendor[];
  onSave: (vendors: Vendor[]) => void;
  onClose: () => void;
}

function VendorFormModal({ vendor, vendors, onSave, onClose }: VendorFormModalProps) {
  const [formData, setFormData] = useState({
    name: vendor?.name || '',
    classroom: vendor?.classroom || '',
    photo: vendor?.photo || '',
    rating: vendor?.rating || 5,
    scheduleStart: vendor?.schedule.start || '08:00',
    scheduleEnd: vendor?.schedule.end || '17:00',
    specialty: vendor?.specialty || ''
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    const newVendor: Vendor = {
      id: vendor?.id || Date.now().toString(),
      name: formData.name,
      classroom: formData.classroom,
      photo: formData.photo,
      rating: formData.rating,
      schedule: {
        start: formData.scheduleStart,
        end: formData.scheduleEnd
      },
      specialty: formData.specialty
    };

    if (vendor) {
      // Edit existing
      onSave(vendors.map(v => v.id === vendor.id ? newVendor : v));
    } else {
      // Add new
      onSave([...vendors, newVendor]);
    }

    onClose();
  };

  return (
    <motion.div
      className="fixed inset-0 bg-black/50 flex items-center justify-center p-4 z-50"
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      onClick={onClose}
    >
      <motion.div
        className="bg-white rounded-2xl shadow-2xl max-w-2xl w-full max-h-[90vh] overflow-y-auto"
        initial={{ scale: 0.9, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        exit={{ scale: 0.9, opacity: 0 }}
        onClick={(e) => e.stopPropagation()}
      >
        <div className="sticky top-0 bg-white border-b border-gray-200 px-6 py-4 flex items-center justify-between">
          <h2 className="text-2xl font-bold text-gray-900">
            {vendor ? 'Editar Vendedor' : 'Novo Vendedor'}
          </h2>
          <button
            onClick={onClose}
            className="text-gray-500 hover:text-gray-700"
          >
            <X size={24} />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-6 space-y-4">
          <div>
            <label className="block text-sm font-semibold text-gray-700 mb-2">
              Nome Completo *
            </label>
            <input
              type="text"
              required
              value={formData.name}
              onChange={(e) => setFormData({ ...formData, name: e.target.value })}
              className="w-full px-4 py-3 rounded-lg border-2 border-gray-200 focus:border-blue-500 focus:outline-none"
              placeholder="Ex: Ana Silva"
            />
          </div>

          <div>
            <label className="block text-sm font-semibold text-gray-700 mb-2">
              Sala de Aula *
            </label>
            <input
              type="text"
              required
              value={formData.classroom}
              onChange={(e) => setFormData({ ...formData, classroom: e.target.value })}
              className="w-full px-4 py-3 rounded-lg border-2 border-gray-200 focus:border-blue-500 focus:outline-none"
              placeholder="Ex: Sala 203"
            />
          </div>

          <div>
            <label className="block text-sm font-semibold text-gray-700 mb-2">
              URL da Foto *
            </label>
            <input
              type="url"
              required
              value={formData.photo}
              onChange={(e) => setFormData({ ...formData, photo: e.target.value })}
              className="w-full px-4 py-3 rounded-lg border-2 border-gray-200 focus:border-blue-500 focus:outline-none"
              placeholder="https://exemplo.com/foto.jpg"
            />
            {formData.photo && (
              <img
                src={formData.photo}
                alt="Preview"
                className="mt-2 w-24 h-24 rounded-full object-cover"
              />
            )}
          </div>

          <div>
            <label className="block text-sm font-semibold text-gray-700 mb-2">
              Especialidade *
            </label>
            <input
              type="text"
              required
              value={formData.specialty}
              onChange={(e) => setFormData({ ...formData, specialty: e.target.value })}
              className="w-full px-4 py-3 rounded-lg border-2 border-gray-200 focus:border-blue-500 focus:outline-none"
              placeholder="Ex: Gelados e Doces"
            />
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-semibold text-gray-700 mb-2">
                Horário Início *
              </label>
              <input
                type="time"
                required
                value={formData.scheduleStart}
                onChange={(e) => setFormData({ ...formData, scheduleStart: e.target.value })}
                className="w-full px-4 py-3 rounded-lg border-2 border-gray-200 focus:border-blue-500 focus:outline-none"
              />
            </div>

            <div>
              <label className="block text-sm font-semibold text-gray-700 mb-2">
                Horário Fim *
              </label>
              <input
                type="time"
                required
                value={formData.scheduleEnd}
                onChange={(e) => setFormData({ ...formData, scheduleEnd: e.target.value })}
                className="w-full px-4 py-3 rounded-lg border-2 border-gray-200 focus:border-blue-500 focus:outline-none"
              />
            </div>
          </div>

          <div>
            <label className="block text-sm font-semibold text-gray-700 mb-2">
              Classificação (estrelas) *
            </label>
            <select
              value={formData.rating}
              onChange={(e) => setFormData({ ...formData, rating: parseFloat(e.target.value) })}
              className="w-full px-4 py-3 rounded-lg border-2 border-gray-200 focus:border-blue-500 focus:outline-none"
            >
              <option value={5}>5 Estrelas</option>
              <option value={4.5}>4.5 Estrelas</option>
              <option value={4}>4 Estrelas</option>
              <option value={3.5}>3.5 Estrelas</option>
              <option value={3}>3 Estrelas</option>
            </select>
          </div>

          <div className="flex gap-3 pt-4">
            <button
              type="button"
              onClick={onClose}
              className="flex-1 px-6 py-3 rounded-lg border-2 border-gray-300 text-gray-700 font-semibold hover:bg-gray-50 transition-colors"
            >
              Cancelar
            </button>
            <button
              type="submit"
              className="flex-1 flex items-center justify-center gap-2 bg-blue-600 text-white px-6 py-3 rounded-lg font-semibold hover:bg-blue-700 transition-colors"
            >
              <Save size={20} />
              Salvar
            </button>
          </div>
        </form>
      </motion.div>
    </motion.div>
  );
}

// Product Form Modal
interface ProductFormModalProps {
  product: Product | null;
  products: Product[];
  vendors: Vendor[];
  onSave: (products: Product[]) => void;
  onClose: () => void;
}

function ProductFormModal({ product, products, vendors, onSave, onClose }: ProductFormModalProps) {
  const [formData, setFormData] = useState({
    name: product?.name || '',
    price: product?.price || 0,
    category: product?.category || 'salgados',
    photos: product?.photos || [''],
    rating: product?.rating || 5,
    vendorId: product?.vendorId || (vendors[0]?.id || '')
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    const selectedVendor = vendors.find(v => v.id === formData.vendorId);
    if (!selectedVendor) {
      alert('Selecione um vendedor válido!');
      return;
    }

    const newProduct: Product = {
      id: product?.id || Date.now().toString(),
      name: formData.name,
      price: formData.price,
      category: formData.category,
      photos: formData.photos.filter(p => p.trim() !== ''),
      rating: formData.rating,
      vendorId: formData.vendorId,
      vendor: selectedVendor
    };

    if (product) {
      // Edit existing
      onSave(products.map(p => p.id === product.id ? newProduct : p));
    } else {
      // Add new
      onSave([...products, newProduct]);
    }

    onClose();
  };

  const updatePhoto = (index: number, value: string) => {
    const newPhotos = [...formData.photos];
    newPhotos[index] = value;
    setFormData({ ...formData, photos: newPhotos });
  };

  const addPhotoField = () => {
    if (formData.photos.length < 3) {
      setFormData({ ...formData, photos: [...formData.photos, ''] });
    }
  };

  const removePhotoField = (index: number) => {
    setFormData({ ...formData, photos: formData.photos.filter((_, i) => i !== index) });
  };

  return (
    <motion.div
      className="fixed inset-0 bg-black/50 flex items-center justify-center p-4 z-50"
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      onClick={onClose}
    >
      <motion.div
        className="bg-white rounded-2xl shadow-2xl max-w-2xl w-full max-h-[90vh] overflow-y-auto"
        initial={{ scale: 0.9, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        exit={{ scale: 0.9, opacity: 0 }}
        onClick={(e) => e.stopPropagation()}
      >
        <div className="sticky top-0 bg-white border-b border-gray-200 px-6 py-4 flex items-center justify-between">
          <h2 className="text-2xl font-bold text-gray-900">
            {product ? 'Editar Produto' : 'Novo Produto'}
          </h2>
          <button
            onClick={onClose}
            className="text-gray-500 hover:text-gray-700"
          >
            <X size={24} />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-6 space-y-4">
          <div>
            <label className="block text-sm font-semibold text-gray-700 mb-2">
              Nome do Produto *
            </label>
            <input
              type="text"
              required
              value={formData.name}
              onChange={(e) => setFormData({ ...formData, name: e.target.value })}
              className="w-full px-4 py-3 rounded-lg border-2 border-gray-200 focus:border-blue-500 focus:outline-none"
              placeholder="Ex: Gelado de Chocolate"
            />
          </div>

          <div>
            <label className="block text-sm font-semibold text-gray-700 mb-2">
              Preço (Kz) *
            </label>
            <input
              type="number"
              required
              min="0"
              value={formData.price}
              onChange={(e) => setFormData({ ...formData, price: parseInt(e.target.value) })}
              className="w-full px-4 py-3 rounded-lg border-2 border-gray-200 focus:border-blue-500 focus:outline-none"
              placeholder="Ex: 150"
            />
          </div>

          <div>
            <label className="block text-sm font-semibold text-gray-700 mb-2">
              Categoria *
            </label>
            <select
              value={formData.category}
              onChange={(e) => setFormData({ ...formData, category: e.target.value })}
              className="w-full px-4 py-3 rounded-lg border-2 border-gray-200 focus:border-blue-500 focus:outline-none"
            >
              <option value="gelados">Gelados</option>
              <option value="bebidas">Bebidas</option>
              <option value="salgados">Salgados</option>
              <option value="doces">Doces</option>
            </select>
          </div>

          <div>
            <label className="block text-sm font-semibold text-gray-700 mb-2">
              Vendedor *
            </label>
            <select
              value={formData.vendorId}
              onChange={(e) => setFormData({ ...formData, vendorId: e.target.value })}
              className="w-full px-4 py-3 rounded-lg border-2 border-gray-200 focus:border-blue-500 focus:outline-none"
            >
              {vendors.map(vendor => (
                <option key={vendor.id} value={vendor.id}>
                  {vendor.name} - {vendor.classroom}
                </option>
              ))}
            </select>
          </div>

          <div>
            <label className="block text-sm font-semibold text-gray-700 mb-2">
              Fotos do Produto (até 3) *
            </label>
            {formData.photos.map((photo, index) => (
              <div key={index} className="flex gap-2 mb-2">
                <input
                  type="url"
                  required={index === 0}
                  value={photo}
                  onChange={(e) => updatePhoto(index, e.target.value)}
                  className="flex-1 px-4 py-3 rounded-lg border-2 border-gray-200 focus:border-blue-500 focus:outline-none"
                  placeholder="https://exemplo.com/foto.jpg"
                />
                {index > 0 && (
                  <button
                    type="button"
                    onClick={() => removePhotoField(index)}
                    className="px-4 py-3 bg-red-500 text-white rounded-lg hover:bg-red-600"
                  >
                    <Trash2 size={20} />
                  </button>
                )}
              </div>
            ))}
            {formData.photos.length < 3 && (
              <button
                type="button"
                onClick={addPhotoField}
                className="text-blue-600 hover:text-blue-700 text-sm font-semibold"
              >
                + Adicionar outra foto
              </button>
            )}
            {formData.photos[0] && (
              <div className="flex gap-2 mt-2">
                {formData.photos.filter(p => p.trim() !== '').map((photo, index) => (
                  <img
                    key={index}
                    src={photo}
                    alt={`Preview ${index + 1}`}
                    className="w-20 h-20 rounded-lg object-cover"
                  />
                ))}
              </div>
            )}
          </div>

          <div>
            <label className="block text-sm font-semibold text-gray-700 mb-2">
              Classificação (estrelas) *
            </label>
            <select
              value={formData.rating}
              onChange={(e) => setFormData({ ...formData, rating: parseFloat(e.target.value) })}
              className="w-full px-4 py-3 rounded-lg border-2 border-gray-200 focus:border-blue-500 focus:outline-none"
            >
              <option value={5}>5 Estrelas</option>
              <option value={4.5}>4.5 Estrelas</option>
              <option value={4}>4 Estrelas</option>
              <option value={3.5}>3.5 Estrelas</option>
              <option value={3}>3 Estrelas</option>
            </select>
          </div>

          <div className="flex gap-3 pt-4">
            <button
              type="button"
              onClick={onClose}
              className="flex-1 px-6 py-3 rounded-lg border-2 border-gray-300 text-gray-700 font-semibold hover:bg-gray-50 transition-colors"
            >
              Cancelar
            </button>
            <button
              type="submit"
              className="flex-1 flex items-center justify-center gap-2 bg-blue-600 text-white px-6 py-3 rounded-lg font-semibold hover:bg-blue-700 transition-colors"
            >
              <Save size={20} />
              Salvar
            </button>
          </div>
        </form>
      </motion.div>
    </motion.div>
  );
}
