import { motion } from 'motion/react';
import { Star } from 'lucide-react';
import { Product } from '../App';

interface ProductCardProps {
  product: Product;
  onVendorClick: (vendorId: string) => void;
}

export function ProductCard({ product, onVendorClick }: ProductCardProps) {
  const renderStars = (rating: number) => {
    const stars = [];
    const fullStars = Math.floor(rating);
    const hasHalfStar = rating % 1 !== 0;

    for (let i = 0; i < fullStars; i++) {
      stars.push(
        <Star key={i} size={14} className="fill-yellow-400 text-yellow-400" />
      );
    }
    if (hasHalfStar) {
      stars.push(
        <Star key="half" size={14} className="fill-yellow-400 text-yellow-400 opacity-50" />
      );
    }
    return stars;
  };

  return (
    <motion.div
      className="bg-white rounded-xl shadow-md overflow-hidden hover:shadow-xl transition-shadow"
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      whileHover={{ y: -5 }}
      transition={{ duration: 0.3 }}
    >
      {/* Product Image */}
      <div className="relative h-48 overflow-hidden bg-gray-100">
        <img
          src={product.photos[0]}
          alt={product.name}
          className="w-full h-full object-cover"
        />
        {product.rating === 5 && (
          <div className="absolute top-2 right-2 bg-yellow-400 text-blue-900 px-3 py-1 rounded-full text-xs font-bold flex items-center gap-1">
            <Star size={12} className="fill-blue-900" />
            Top
          </div>
        )}
      </div>

      {/* Product Info */}
      <div className="p-4">
        <h3 className="font-bold text-lg text-gray-800 mb-2">{product.name}</h3>
        
        {/* Price */}
        <div className="flex items-center justify-between mb-3">
          <p className="text-2xl font-bold text-blue-600">{product.price} Kz</p>
          <div className="flex items-center gap-1">
            {renderStars(product.rating)}
          </div>
        </div>

        {/* Category */}
        <div className="mb-3">
          <span className="inline-block bg-blue-100 text-blue-700 px-3 py-1 rounded-full text-xs font-semibold capitalize">
            {product.category}
          </span>
        </div>

        {/* Vendor Info */}
        <div className="border-t pt-3 mt-3">
          <button
            onClick={() => onVendorClick(product.vendorId)}
            className="flex items-center gap-2 w-full hover:bg-gray-50 p-2 rounded-lg transition-colors"
          >
            <img
              src={product.vendor.photo}
              alt={product.vendor.name}
              className="w-10 h-10 rounded-full object-cover border-2 border-blue-200"
            />
            <div className="text-left flex-1">
              <p className="font-semibold text-sm text-gray-800">{product.vendor.name}</p>
              <p className="text-xs text-gray-500">{product.vendor.classroom}</p>
            </div>
            <div className="flex items-center gap-1">
              <Star size={12} className="fill-yellow-400 text-yellow-400" />
              <span className="text-xs font-semibold text-gray-700">{product.vendor.rating}</span>
            </div>
          </button>
        </div>
      </div>
    </motion.div>
  );
}
