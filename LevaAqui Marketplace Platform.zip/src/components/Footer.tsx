import { ShoppingBag, Heart } from 'lucide-react';

export function Footer() {
  return (
    <footer className="bg-gradient-to-r from-blue-900 to-blue-800 text-white py-12 px-4">
      <div className="max-w-7xl mx-auto">
        <div className="grid md:grid-cols-3 gap-8 mb-8">
          {/* Brand */}
          <div>
            <div className="flex items-center gap-2 mb-4">
              <div className="bg-gradient-to-br from-blue-500 to-yellow-400 p-2 rounded-lg">
                <ShoppingBag className="text-white" size={24} />
              </div>
              <div>
                <h3 className="text-xl font-bold">LevaAqui</h3>
                <p className="text-xs text-blue-300">IMETRO Marketplace</p>
              </div>
            </div>
            <p className="text-blue-200 text-sm">
              Plataforma de vendas criada por estudantes do IMETRO para conectar 
              compradores e vendedores dentro do campus.
            </p>
          </div>

          {/* Links */}
          <div>
            <h4 className="font-bold text-lg mb-4">Links Rápidos</h4>
            <ul className="space-y-2 text-blue-200">
              <li>
                <a href="#home" className="hover:text-yellow-300 transition-colors">
                  Início
                </a>
              </li>
              <li>
                <a href="#products" className="hover:text-yellow-300 transition-colors">
                  Produtos
                </a>
              </li>
              <li>
                <a href="#about" className="hover:text-yellow-300 transition-colors">
                  Sobre Nós
                </a>
              </li>
              <li>
                <a href="#location" className="hover:text-yellow-300 transition-colors">
                  Localização
                </a>
              </li>
            </ul>
          </div>

          {/* Contact */}
          <div>
            <h4 className="font-bold text-lg mb-4">Informações</h4>
            <ul className="space-y-2 text-blue-200 text-sm">
              <li>📍 Campus IMETRO, atrás do campo</li>
              <li>🕒 Seg-Sex: 8h - 17h</li>
              <li>🕒 Sábado: 9h - 13h</li>
              <li className="pt-2">
                <span className="text-yellow-300 font-semibold">
                  Visite nosso espaço no campus!
                </span>
              </li>
            </ul>
          </div>
        </div>

        {/* Bottom */}
        <div className="border-t border-blue-700 pt-6 text-center">
          <p className="text-blue-200 text-sm flex items-center justify-center gap-2 flex-wrap">
            <span>© 2024 LevaAqui - IMETRO</span>
            <span>•</span>
            <span className="flex items-center gap-1">
              Feito com <Heart size={14} className="fill-red-500 text-red-500" /> por Estudantes do IMETRO
            </span>
          </p>
        </div>
      </div>
    </footer>
  );
}
