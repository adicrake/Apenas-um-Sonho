import { motion } from 'motion/react';
import { Star, MapPin, Clock, ShoppingBag, Award, Filter, Sparkles } from 'lucide-react';
import { Vendor, Product } from '../App';
import { isVendorAvailable, getNextAvailableTime } from '../utils/timeUtils';
import { useState } from 'react';

interface VendorListSectionProps {
  vendors: Vendor[];
  products: Product[];
  onVendorClick: (vendorId: string) => void;
}

export function VendorListSection({ vendors, products, onVendorClick }: VendorListSectionProps) {
  const [filterBy, setFilterBy] = useState<'all' | 'available' | 'top-rated'>('all');

  const getVendorProductCount = (vendorId: string) => {
    return products.filter(p => p.vendorId === vendorId).length;
  };

  const renderStars = (rating: number) => {
    const stars = [];
    const fullStars = Math.floor(rating);
    const hasHalfStar = rating % 1 !== 0;

    for (let i = 0; i < fullStars; i++) {
      stars.push(
        <Star key={i} size={16} className="fill-yellow-400 text-yellow-400" />
      );
    }
    if (hasHalfStar) {
      stars.push(
        <Star key="half" size={16} className="fill-yellow-400 text-yellow-400 opacity-50" />
      );
    }
    return stars;
  };

  const filteredVendors = vendors.filter(vendor => {
    if (filterBy === 'available') return isVendorAvailable(vendor.schedule);
    if (filterBy === 'top-rated') return vendor.rating === 5;
    return true;
  });

  const availableCount = vendors.filter(v => isVendorAvailable(v.schedule)).length;
  const topRatedCount = vendors.filter(v => v.rating === 5).length;

  return (
    <section className="py-16 px-4 max-w-7xl mx-auto">
      <div className="text-center mb-12">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
        >
          <h2 className="text-4xl font-bold text-blue-900 mb-4">
            Nossos Vendedores
          </h2>
          <p className="text-lg text-gray-600 max-w-2xl mx-auto">
            Conheça os estudantes que tornam o LevaAqui possível. Clique em um vendedor para ver seus produtos.
          </p>
        </motion.div>
      </div>

      {/* Filter Buttons */}
      <motion.div
        className="flex flex-wrap justify-center gap-3 mb-8"
        initial={{ opacity: 0, y: -10 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5, delay: 0.2 }}
      >
        <button
          onClick={() => setFilterBy('all')}
          className={`px-6 py-2.5 rounded-full font-semibold transition-all flex items-center gap-2 ${
            filterBy === 'all'
              ? 'bg-gradient-to-r from-blue-600 to-blue-500 text-white shadow-lg'
              : 'bg-white text-gray-700 hover:bg-gray-100 border border-gray-200'
          }`}
        >
          <Filter size={18} />
          Todos ({vendors.length})
        </button>
        <button
          onClick={() => setFilterBy('available')}
          className={`px-6 py-2.5 rounded-full font-semibold transition-all flex items-center gap-2 ${
            filterBy === 'available'
              ? 'bg-gradient-to-r from-green-600 to-green-500 text-white shadow-lg'
              : 'bg-white text-gray-700 hover:bg-gray-100 border border-gray-200'
          }`}
        >
          <div className="w-2 h-2 bg-green-400 rounded-full animate-pulse"></div>
          Disponíveis ({availableCount})
        </button>
        <button
          onClick={() => setFilterBy('top-rated')}
          className={`px-6 py-2.5 rounded-full font-semibold transition-all flex items-center gap-2 ${
            filterBy === 'top-rated'
              ? 'bg-gradient-to-r from-yellow-500 to-yellow-400 text-blue-900 shadow-lg'
              : 'bg-white text-gray-700 hover:bg-gray-100 border border-gray-200'
          }`}
        >
          <Sparkles size={18} />
          5 Estrelas ({topRatedCount})
        </button>
      </motion.div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredVendors.map((vendor, index) => {
          const productCount = getVendorProductCount(vendor.id);
          const isTopRated = vendor.rating === 5;
          const isAvailable = isVendorAvailable(vendor.schedule);
          const nextAvailable = getNextAvailableTime(vendor.schedule);

          return (
            <motion.div
              key={vendor.id}
              className="group relative bg-white rounded-2xl shadow-md hover:shadow-2xl transition-all duration-300 overflow-hidden cursor-pointer"
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: index * 0.1 }}
              whileHover={{ y: -8 }}
              onClick={() => onVendorClick(vendor.id)}
            >
              {/* Availability Badge */}
              <div className="absolute top-4 left-4 z-10">
                {isAvailable ? (
                  <motion.div
                    className="bg-green-500 text-white px-3 py-1.5 rounded-full text-xs font-bold flex items-center gap-2 shadow-lg"
                    initial={{ scale: 0 }}
                    animate={{ scale: 1 }}
                    transition={{ duration: 0.3, delay: index * 0.1 + 0.2 }}
                  >
                    <div className="w-2 h-2 bg-white rounded-full animate-pulse"></div>
                    Disponível Agora
                  </motion.div>
                ) : (
                  <motion.div
                    className="bg-gray-600 text-white px-3 py-1.5 rounded-full text-xs font-bold shadow-lg"
                    initial={{ scale: 0 }}
                    animate={{ scale: 1 }}
                    transition={{ duration: 0.3, delay: index * 0.1 + 0.2 }}
                  >
                    Produto na Loja
                  </motion.div>
                )}
              </div>

              {/* Top Rated Badge */}
              {isTopRated && (
                <div className="absolute top-4 right-4 z-10">
                  <motion.div
                    className="bg-gradient-to-r from-yellow-400 to-yellow-500 text-blue-900 px-3 py-1 rounded-full text-xs font-bold flex items-center gap-1 shadow-lg"
                    initial={{ scale: 0 }}
                    animate={{ scale: 1 }}
                    transition={{ duration: 0.3, delay: index * 0.1 + 0.3 }}
                  >
                    <Award size={12} />
                    Top
                  </motion.div>
                </div>
              )}

              {/* Header with gradient */}
              <div className="relative h-32 bg-gradient-to-br from-blue-600 via-blue-500 to-yellow-400">
                <div className="absolute inset-0 bg-black/10"></div>
                <div className="absolute -bottom-16 left-1/2 transform -translate-x-1/2">
                  <div className="relative">
                    <div className="w-32 h-32 rounded-full border-4 border-white shadow-xl overflow-hidden bg-white">
                      <img
                        src={vendor.photo}
                        alt={vendor.name}
                        className="w-full h-full object-cover"
                      />
                    </div>
                    {/* Status indicator */}
                    <div className={`absolute bottom-2 right-2 w-6 h-6 rounded-full border-4 border-white ${
                      isAvailable ? 'bg-green-500' : 'bg-gray-400'
                    }`}></div>
                  </div>
                </div>
              </div>

              {/* Content */}
              <div className="pt-20 px-6 pb-6">
                {/* Name and Rating */}
                <div className="text-center mb-4">
                  <h3 className="text-xl font-bold text-gray-900 mb-2">
                    {vendor.name}
                  </h3>
                  <div className="flex items-center justify-center gap-2 mb-2">
                    <div className="flex items-center gap-1">
                      {renderStars(vendor.rating)}
                    </div>
                    <span className="text-sm font-semibold text-gray-700">
                      {vendor.rating}
                    </span>
                  </div>
                  <div className="inline-block bg-blue-50 text-blue-700 px-3 py-1 rounded-full text-xs font-semibold">
                    {vendor.specialty}
                  </div>
                </div>

                {/* Info Cards */}
                <div className="space-y-2 mb-6">
                  <div className="flex items-center gap-3 bg-gray-50 rounded-lg p-3">
                    <div className="bg-blue-100 p-2 rounded-lg">
                      <MapPin size={16} className="text-blue-600" />
                    </div>
                    <div className="flex-1">
                      <p className="text-xs text-gray-500 font-medium">Sala</p>
                      <p className="text-sm font-semibold text-gray-800">{vendor.classroom}</p>
                    </div>
                  </div>

                  <div className="flex items-center gap-3 bg-gray-50 rounded-lg p-3">
                    <div className={`p-2 rounded-lg ${
                      isAvailable ? 'bg-green-100' : 'bg-gray-200'
                    }`}>
                      <Clock size={16} className={isAvailable ? 'text-green-600' : 'text-gray-600'} />
                    </div>
                    <div className="flex-1">
                      <p className="text-xs text-gray-500 font-medium">Horário de Venda</p>
                      <p className="text-sm font-semibold text-gray-800">
                        {vendor.schedule.start} - {vendor.schedule.end}
                      </p>
                      {!isAvailable && nextAvailable && (
                        <p className="text-xs text-gray-500 mt-0.5">
                          Próximo às {nextAvailable}
                        </p>
                      )}
                    </div>
                  </div>

                  <div className="flex items-center gap-3 bg-gray-50 rounded-lg p-3">
                    <div className="bg-yellow-100 p-2 rounded-lg">
                      <ShoppingBag size={16} className="text-yellow-600" />
                    </div>
                    <div className="flex-1">
                      <p className="text-xs text-gray-500 font-medium">Produtos</p>
                      <p className="text-sm font-semibold text-gray-800">
                        {productCount} {productCount === 1 ? 'produto' : 'produtos'}
                      </p>
                    </div>
                  </div>
                </div>

                {/* CTA Button */}
                <motion.button
                  className={`w-full py-3 rounded-xl font-semibold transition-all shadow-md group-hover:shadow-lg ${
                    isAvailable
                      ? 'bg-gradient-to-r from-green-600 to-green-500 text-white hover:from-green-700 hover:to-green-600'
                      : 'bg-gradient-to-r from-blue-600 to-blue-500 text-white hover:from-blue-700 hover:to-blue-600'
                  }`}
                  whileHover={{ scale: 1.02 }}
                  whileTap={{ scale: 0.98 }}
                >
                  {isAvailable ? 'Comprar Agora' : 'Ver Produtos'}
                </motion.button>
              </div>
            </motion.div>
          );
        })}
      </div>

      {filteredVendors.length === 0 && (
        <div className="text-center py-16">
          <p className="text-xl text-gray-500">Nenhum vendedor encontrado com este filtro</p>
          <button
            onClick={() => setFilterBy('all')}
            className="mt-4 text-blue-600 hover:text-blue-700 font-semibold"
          >
            Ver todos os vendedores
          </button>
        </div>
      )}

      {/* Stats Bar */}
      <motion.div
        className="mt-16 bg-gradient-to-r from-blue-600 to-blue-500 rounded-2xl p-8 text-white"
        initial={{ opacity: 0, y: 30 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6, delay: 0.4 }}
      >
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8 text-center">
          <div>
            <p className="text-4xl font-bold mb-2">{vendors.length}</p>
            <p className="text-blue-100">Vendedores Ativos</p>
          </div>
          <div>
            <div className="flex items-center justify-center gap-2 mb-2">
              <div className="w-3 h-3 bg-green-400 rounded-full animate-pulse"></div>
              <p className="text-4xl font-bold">{availableCount}</p>
            </div>
            <p className="text-blue-100">Disponíveis Agora</p>
          </div>
          <div>
            <p className="text-4xl font-bold mb-2">{products.length}</p>
            <p className="text-blue-100">Produtos Disponíveis</p>
          </div>
          <div>
            <p className="text-4xl font-bold mb-2">{topRatedCount}</p>
            <p className="text-blue-100">Vendedores 5 Estrelas</p>
          </div>
        </div>
      </motion.div>
    </section>
  );
}
