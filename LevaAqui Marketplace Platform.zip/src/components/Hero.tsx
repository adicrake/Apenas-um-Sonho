import { motion } from 'motion/react';
import { ShoppingBag, Users, TrendingUp } from 'lucide-react';

export function Hero() {
  return (
    <section id="home" className="relative overflow-hidden bg-gradient-to-br from-blue-600 via-blue-500 to-yellow-400 text-white py-20 px-4">
      <div className="max-w-7xl mx-auto">
        <div className="grid md:grid-cols-2 gap-12 items-center">
          {/* Left Content */}
          <motion.div
            initial={{ opacity: 0, x: -50 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.7 }}
          >
            <h1 className="text-5xl md:text-6xl font-bold mb-6 leading-tight">
              Bem-vindo ao
              <span className="block text-yellow-300">LevaAqui</span>
            </h1>
            <p className="text-xl mb-8 text-blue-50">
              O marketplace feito por estudantes do IMETRO, para estudantes. 
              Compre e venda produtos diretamente no campus!
            </p>
            
            <div className="flex flex-wrap gap-4 mb-8">
              <motion.a
                href="#products"
                className="bg-white text-blue-600 px-8 py-3 rounded-full font-bold hover:bg-yellow-300 hover:text-blue-700 transition-colors shadow-lg"
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
              >
                Ver Produtos
              </motion.a>
              <motion.a
                href="#about"
                className="bg-transparent border-2 border-white text-white px-8 py-3 rounded-full font-bold hover:bg-white hover:text-blue-600 transition-colors"
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
              >
                Saiba Mais
              </motion.a>
            </div>

            {/* Stats */}
            <div className="grid grid-cols-3 gap-6">
              <motion.div
                className="text-center"
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5, delay: 0.2 }}
              >
                <ShoppingBag className="mx-auto mb-2" size={32} />
                <p className="text-2xl font-bold">50+</p>
                <p className="text-sm text-blue-100">Produtos</p>
              </motion.div>
              <motion.div
                className="text-center"
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5, delay: 0.3 }}
              >
                <Users className="mx-auto mb-2" size={32} />
                <p className="text-2xl font-bold">15+</p>
                <p className="text-sm text-blue-100">Vendedores</p>
              </motion.div>
              <motion.div
                className="text-center"
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5, delay: 0.4 }}
              >
                <TrendingUp className="mx-auto mb-2" size={32} />
                <p className="text-2xl font-bold">100%</p>
                <p className="text-sm text-blue-100">Estudantes</p>
              </motion.div>
            </div>
          </motion.div>

          {/* Right Content - Image */}
          <motion.div
            className="relative"
            initial={{ opacity: 0, x: 50 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.7, delay: 0.2 }}
          >
            <div className="relative rounded-2xl overflow-hidden shadow-2xl">
              <img
                src="https://images.unsplash.com/photo-1523050854058-8df90110c9f1?w=600&h=600&fit=crop"
                alt="Estudantes IMETRO"
                className="w-full h-auto"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-blue-900/50 to-transparent"></div>
            </div>
            
            {/* Floating Card */}
            <motion.div
              className="absolute -bottom-6 -left-6 bg-white text-blue-900 p-4 rounded-xl shadow-xl"
              initial={{ opacity: 0, scale: 0.8 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ duration: 0.5, delay: 0.8 }}
            >
              <p className="text-sm font-semibold text-gray-600">Feito por:</p>
              <p className="text-lg font-bold">Estudantes IMETRO</p>
            </motion.div>
          </motion.div>
        </div>
      </div>

      {/* Decorative Elements */}
      <div className="absolute top-0 right-0 w-64 h-64 bg-yellow-300 rounded-full blur-3xl opacity-20"></div>
      <div className="absolute bottom-0 left-0 w-64 h-64 bg-blue-800 rounded-full blur-3xl opacity-20"></div>
    </section>
  );
}
