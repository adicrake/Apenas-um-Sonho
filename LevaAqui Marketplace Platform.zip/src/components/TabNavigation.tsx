import { motion } from 'motion/react';
import { ShoppingBag, Users } from 'lucide-react';

interface TabNavigationProps {
  activeTab: 'products' | 'vendors';
  onTabChange: (tab: 'products' | 'vendors') => void;
}

export function TabNavigation({ activeTab, onTabChange }: TabNavigationProps) {
  return (
    <div className="bg-white shadow-sm sticky top-[73px] z-40 border-b border-gray-200">
      <div className="max-w-7xl mx-auto px-4">
        <div className="flex gap-2">
          <button
            onClick={() => onTabChange('products')}
            className="relative px-8 py-4 font-semibold text-gray-700 hover:text-blue-600 transition-colors flex items-center gap-2"
          >
            <ShoppingBag size={20} />
            <span>Produtos</span>
            {activeTab === 'products' && (
              <motion.div
                className="absolute bottom-0 left-0 right-0 h-1 bg-gradient-to-r from-blue-600 to-blue-500"
                layoutId="activeTab"
                transition={{ type: 'spring', stiffness: 300, damping: 30 }}
              />
            )}
          </button>

          <button
            onClick={() => onTabChange('vendors')}
            className="relative px-8 py-4 font-semibold text-gray-700 hover:text-blue-600 transition-colors flex items-center gap-2"
          >
            <Users size={20} />
            <span>Vendedores</span>
            {activeTab === 'vendors' && (
              <motion.div
                className="absolute bottom-0 left-0 right-0 h-1 bg-gradient-to-r from-blue-600 to-blue-500"
                layoutId="activeTab"
                transition={{ type: 'spring', stiffness: 300, damping: 30 }}
              />
            )}
          </button>
        </div>
      </div>
    </div>
  );
}
