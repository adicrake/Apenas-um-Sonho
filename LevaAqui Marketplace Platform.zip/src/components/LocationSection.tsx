import { motion } from 'motion/react';
import { MapPin, Clock, Phone } from 'lucide-react';

export function LocationSection() {
  return (
    <section id="location" className="py-16 px-4 bg-white">
      <div className="max-w-7xl mx-auto">
        <motion.div
          className="text-center mb-12"
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
        >
          <h2 className="text-4xl font-bold text-blue-900 mb-4">
            Visite Nosso Espaço
          </h2>
          <p className="text-lg text-gray-600">
            Encontre-nos no campus do IMETRO
          </p>
        </motion.div>

        <div className="grid md:grid-cols-2 gap-8 items-center">
          {/* Location Info */}
          <motion.div
            className="space-y-6"
            initial={{ opacity: 0, x: -30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
          >
            <div className="bg-gradient-to-br from-blue-50 to-yellow-50 p-8 rounded-xl shadow-md">
              <div className="flex items-start gap-4 mb-6">
                <div className="bg-blue-500 p-3 rounded-lg">
                  <MapPin className="text-white" size={24} />
                </div>
                <div>
                  <h3 className="text-xl font-bold text-blue-900 mb-2">Localização</h3>
                  <p className="text-gray-700">
                    Campus do IMETRO<br />
                    <span className="font-semibold">Atrás do campo de futebol</span>
                  </p>
                </div>
              </div>

              <div className="flex items-start gap-4 mb-6">
                <div className="bg-yellow-500 p-3 rounded-lg">
                  <Clock className="text-white" size={24} />
                </div>
                <div>
                  <h3 className="text-xl font-bold text-blue-900 mb-2">Horário</h3>
                  <p className="text-gray-700">
                    Segunda a Sexta: 8h - 17h<br />
                    Sábado: 9h - 13h
                  </p>
                </div>
              </div>

              <div className="flex items-start gap-4">
                <div className="bg-blue-500 p-3 rounded-lg">
                  <Phone className="text-white" size={24} />
                </div>
                <div>
                  <h3 className="text-xl font-bold text-blue-900 mb-2">Contacto</h3>
                  <p className="text-gray-700">
                    Venha nos visitar pessoalmente<br />
                    ou encontre os vendedores nas suas salas
                  </p>
                </div>
              </div>
            </div>

            <motion.div
              className="bg-gradient-to-r from-blue-600 to-blue-500 text-white p-6 rounded-xl"
              whileHover={{ scale: 1.02 }}
              transition={{ duration: 0.2 }}
            >
              <p className="text-lg font-semibold mb-2">💡 Dica</p>
              <p>
                Você também pode encontrar os vendedores diretamente nas suas salas de aula 
                durante os intervalos!
              </p>
            </motion.div>
          </motion.div>

          {/* Location Image */}
          <motion.div
            className="relative rounded-2xl overflow-hidden shadow-xl"
            initial={{ opacity: 0, x: 30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
          >
            <img
              src="https://images.unsplash.com/photo-1562774053-701939374585?w=600&h=500&fit=crop"
              alt="Campus IMETRO"
              className="w-full h-full object-cover"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-blue-900/60 to-transparent flex items-end">
              <div className="p-6 text-white">
                <h4 className="text-2xl font-bold mb-2">Campus IMETRO</h4>
                <p className="text-blue-100">Nosso espaço fica atrás do campo</p>
              </div>
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
}
