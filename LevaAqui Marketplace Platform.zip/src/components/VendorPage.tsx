import { motion } from 'motion/react';
import { ArrowLeft, Star, MapPin, Clock, ShoppingBag } from 'lucide-react';
import { Vendor, Product } from '../App';
import { ProductCard } from './ProductCard';
import { isVendorAvailable } from '../utils/timeUtils';

interface VendorPageProps {
  vendor: Vendor;
  products: Product[];
  onBack: () => void;
}

export function VendorPage({ vendor, products, onBack }: VendorPageProps) {
  const isAvailable = isVendorAvailable(vendor.schedule);
  
  const renderStars = (rating: number) => {
    const stars = [];
    const fullStars = Math.floor(rating);
    const hasHalfStar = rating % 1 !== 0;

    for (let i = 0; i < fullStars; i++) {
      stars.push(
        <Star key={i} size={20} className="fill-yellow-400 text-yellow-400" />
      );
    }
    if (hasHalfStar) {
      stars.push(
        <Star key="half" size={20} className="fill-yellow-400 text-yellow-400 opacity-50" />
      );
    }
    return stars;
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-blue-50 to-yellow-50">
      {/* Header */}
      <div className="bg-white shadow-md sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 py-4">
          <button
            onClick={onBack}
            className="flex items-center gap-2 text-blue-600 hover:text-blue-700 font-semibold"
          >
            <ArrowLeft size={20} />
            Voltar
          </button>
        </div>
      </div>

      {/* Vendor Profile Section */}
      <motion.div
        className="bg-gradient-to-r from-blue-600 to-blue-500 text-white py-12 px-4"
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ duration: 0.5 }}
      >
        <div className="max-w-7xl mx-auto">
          <div className="flex flex-col md:flex-row items-center gap-8">
            <motion.div
              className="relative"
              initial={{ scale: 0.8, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              transition={{ duration: 0.5, delay: 0.2 }}
            >
              <img
                src={vendor.photo}
                alt={vendor.name}
                className="w-32 h-32 rounded-full object-cover border-4 border-white shadow-xl"
              />
              <div className={`absolute bottom-2 right-2 w-8 h-8 rounded-full border-4 border-white ${
                isAvailable ? 'bg-green-500' : 'bg-gray-400'
              }`}></div>
            </motion.div>
            
            <div className="text-center md:text-left flex-1">
              <motion.h1
                className="text-4xl font-bold mb-2"
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ duration: 0.5, delay: 0.3 }}
              >
                {vendor.name}
              </motion.h1>
              
              <motion.div
                className="flex items-center gap-2 justify-center md:justify-start mb-3"
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ duration: 0.5, delay: 0.4 }}
              >
                {renderStars(vendor.rating)}
                <span className="text-lg font-semibold ml-2">{vendor.rating}</span>
              </motion.div>

              <motion.div
                className="inline-block bg-white/20 backdrop-blur-sm text-white px-4 py-2 rounded-full text-sm font-semibold mb-4"
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ duration: 0.5, delay: 0.45 }}
              >
                {vendor.specialty}
              </motion.div>

              <motion.div
                className="flex flex-wrap gap-4 justify-center md:justify-start text-blue-100"
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ duration: 0.5, delay: 0.5 }}
              >
                <div className="flex items-center gap-2 bg-white/10 backdrop-blur-sm px-4 py-2 rounded-lg">
                  <MapPin size={18} />
                  <span>{vendor.classroom}</span>
                </div>
                <div className="flex items-center gap-2 bg-white/10 backdrop-blur-sm px-4 py-2 rounded-lg">
                  <Clock size={18} />
                  <span>{vendor.schedule.start} - {vendor.schedule.end}</span>
                </div>
                <div className={`flex items-center gap-2 px-4 py-2 rounded-lg font-semibold ${
                  isAvailable 
                    ? 'bg-green-500 text-white' 
                    : 'bg-white/10 backdrop-blur-sm'
                }`}>
                  <div className={`w-2 h-2 rounded-full ${
                    isAvailable ? 'bg-white animate-pulse' : 'bg-gray-300'
                  }`}></div>
                  <span>{isAvailable ? 'Disponível Agora' : 'Produto na Loja'}</span>
                </div>
              </motion.div>
            </div>

            <motion.div
              className="bg-white text-blue-900 px-8 py-6 rounded-xl shadow-lg"
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ duration: 0.5, delay: 0.6 }}
            >
              <div className="flex items-center gap-3 mb-2">
                <ShoppingBag size={24} className="text-blue-600" />
                <p className="text-3xl font-bold">{products.length}</p>
              </div>
              <p className="text-sm text-gray-600">Produtos Disponíveis</p>
            </motion.div>
          </div>
        </div>
      </motion.div>

      {/* Products Section */}
      <div className="max-w-7xl mx-auto px-4 py-12">
        <motion.h2
          className="text-3xl font-bold text-blue-900 mb-8"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.3 }}
        >
          Produtos de {vendor.name}
        </motion.h2>

        {products.length === 0 ? (
          <div className="text-center py-16">
            <p className="text-xl text-gray-500">Nenhum produto disponível no momento</p>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {products.map((product, index) => (
              <motion.div
                key={product.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5, delay: index * 0.1 }}
              >
                <ProductCard
                  product={product}
                  onVendorClick={() => {}}
                />
              </motion.div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}