import { motion } from 'motion/react';
import { Heart, Users, Zap } from 'lucide-react';

export function AboutSection() {
  return (
    <section id="about" className="py-16 px-4 bg-white">
      <div className="max-w-7xl mx-auto">
        <motion.div
          className="text-center mb-12"
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
        >
          <h2 className="text-4xl font-bold text-blue-900 mb-4">
            Sobre o LevaAqui
          </h2>
          <p className="text-lg text-gray-600 max-w-3xl mx-auto">
            Uma plataforma criada por estudantes do Instituto Superior Politécnico de Angola (IMETRO) 
            para facilitar a compra e venda de produtos entre alunos do campus.
          </p>
        </motion.div>

        {/* Features Grid */}
        <div className="grid md:grid-cols-3 gap-8 mb-12">
          <motion.div
            className="text-center p-6 rounded-xl bg-blue-50 hover:bg-blue-100 transition-colors"
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5, delay: 0.1 }}
            whileHover={{ scale: 1.05 }}
          >
            <div className="bg-blue-500 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
              <Heart className="text-white" size={32} />
            </div>
            <h3 className="text-xl font-bold text-blue-900 mb-2">Feito com Paixão</h3>
            <p className="text-gray-600">
              Desenvolvido por estudantes que entendem as necessidades do campus.
            </p>
          </motion.div>

          <motion.div
            className="text-center p-6 rounded-xl bg-yellow-50 hover:bg-yellow-100 transition-colors"
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5, delay: 0.2 }}
            whileHover={{ scale: 1.05 }}
          >
            <div className="bg-yellow-500 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
              <Users className="text-white" size={32} />
            </div>
            <h3 className="text-xl font-bold text-blue-900 mb-2">Comunidade Forte</h3>
            <p className="text-gray-600">
              Conectando vendedores e compradores dentro do IMETRO.
            </p>
          </motion.div>

          <motion.div
            className="text-center p-6 rounded-xl bg-blue-50 hover:bg-blue-100 transition-colors"
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5, delay: 0.3 }}
            whileHover={{ scale: 1.05 }}
          >
            <div className="bg-blue-500 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
              <Zap className="text-white" size={32} />
            </div>
            <h3 className="text-xl font-bold text-blue-900 mb-2">Rápido e Fácil</h3>
            <p className="text-gray-600">
              Encontre o que precisa em segundos, direto no campus.
            </p>
          </motion.div>
        </div>

        {/* Team Photo Section */}
        <motion.div
          className="bg-gradient-to-r from-blue-100 to-yellow-100 rounded-2xl overflow-hidden shadow-lg"
          initial={{ opacity: 0, scale: 0.95 }}
          whileInView={{ opacity: 1, scale: 1 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
        >
          <div className="grid md:grid-cols-2 gap-8 items-center">
            <div className="p-8 md:p-12">
              <h3 className="text-3xl font-bold text-blue-900 mb-4">
                Nossa Equipe
              </h3>
              <p className="text-gray-700 mb-6">
                Somos um grupo de estudantes apaixonados por tecnologia e inovação, 
                trabalhando juntos para tornar a vida no campus mais prática e conectada.
              </p>
              <p className="text-gray-700">
                Este projeto nasceu da necessidade de criar um espaço digital onde 
                os alunos do IMETRO possam comprar e vender produtos de forma organizada, 
                transparente e acessível.
              </p>
            </div>
            <div className="h-full">
              <img
                src="https://images.unsplash.com/photo-1522071820081-009f0129c71c?w=600&h=400&fit=crop"
                alt="Equipe LevaAqui"
                className="w-full h-full object-cover"
              />
            </div>
          </div>
        </motion.div>
      </div>
    </section>
  );
}
