export function isVendorAvailable(schedule: { start: string; end: string }): boolean {
  const now = new Date();
  const currentTime = now.getHours() * 60 + now.getMinutes();
  
  const [startHour, startMin] = schedule.start.split(':').map(Number);
  const [endHour, endMin] = schedule.end.split(':').map(Number);
  
  const startTime = startHour * 60 + startMin;
  const endTime = endHour * 60 + endMin;
  
  return currentTime >= startTime && currentTime <= endTime;
}

export function getNextAvailableTime(schedule: { start: string; end: string }): string | null {
  const now = new Date();
  const currentTime = now.getHours() * 60 + now.getMinutes();
  
  const [startHour, startMin] = schedule.start.split(':').map(Number);
  const startTime = startHour * 60 + startMin;
  
  if (currentTime < startTime) {
    return schedule.start;
  }
  
  return null;
}

export function formatTime(time: string): string {
  return time;
}
