import { useState, useEffect } from 'react';
import { Header } from './components/Header';
import { Hero } from './components/Hero';
import { ProductGrid } from './components/ProductGrid';
import { CategoryFilter } from './components/CategoryFilter';
import { SearchBar } from './components/SearchBar';
import { VendorPage } from './components/VendorPage';
import { AboutSection } from './components/AboutSection';
import { LocationSection } from './components/LocationSection';
import { Footer } from './components/Footer';
import { TabNavigation } from './components/TabNavigation';
import { VendorListSection } from './components/VendorListSection';
import { AdminPanel } from './components/AdminPanel';

// Mock data - será substituído por dados reais do Supabase
export interface Vendor {
  id: string;
  name: string;
  classroom: string;
  photo: string;
  rating: number;
  schedule: {
    start: string; // Formato: "HH:MM"
    end: string;   // Formato: "HH:MM"
  };
  specialty: string; // Categoria principal do vendedor
}

export interface Product {
  id: string;
  name: string;
  price: number;
  category: string;
  photos: string[];
  rating: number;
  vendorId: string;
  vendor: Vendor;
}

const mockVendors: Vendor[] = [
  {
    id: '1',
    name: 'Ana Silva',
    classroom: 'Sala 203',
    photo: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=200&h=200&fit=crop',
    rating: 5,
    schedule: { start: '08:00', end: '14:00' },
    specialty: 'Gelados e Doces'
  },
  {
    id: '2',
    name: 'João Mendes',
    classroom: 'Sala 105',
    photo: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=200&h=200&fit=crop',
    rating: 4.5,
    schedule: { start: '10:00', end: '16:00' },
    specialty: 'Bebidas Naturais'
  },
  {
    id: '3',
    name: 'Maria Costa',
    classroom: 'Sala 301',
    photo: 'https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=200&h=200&fit=crop',
    rating: 5,
    schedule: { start: '07:30', end: '17:00' },
    specialty: 'Salgados e Doces'
  },
  {
    id: '4',
    name: 'Carlos Ferreira',
    classroom: 'Sala 210',
    photo: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=200&h=200&fit=crop',
    rating: 4.5,
    schedule: { start: '09:00', end: '15:00' },
    specialty: 'Salgados'
  },
  {
    id: '5',
    name: 'Sofia Martins',
    classroom: 'Sala 115',
    photo: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=200&h=200&fit=crop',
    rating: 5,
    schedule: { start: '08:30', end: '16:30' },
    specialty: 'Gelados e Salgados'
  },
  {
    id: '6',
    name: 'Pedro Santos',
    classroom: 'Sala 302',
    photo: 'https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?w=200&h=200&fit=crop',
    rating: 4,
    schedule: { start: '11:00', end: '17:00' },
    specialty: 'Bebidas'
  }
];

const mockProducts: Product[] = [
  {
    id: '1',
    name: 'Gelado de Chocolate',
    price: 150,
    category: 'gelados',
    photos: [
      'https://images.unsplash.com/photo-1563805042-7684c019e1cb?w=400&h=400&fit=crop',
      'https://images.unsplash.com/photo-1497034825429-c343d7c6a68f?w=400&h=400&fit=crop'
    ],
    rating: 5,
    vendorId: '1',
    vendor: mockVendors[0]
  },
  {
    id: '2',
    name: 'Sumo Natural de Laranja',
    price: 200,
    category: 'bebidas',
    photos: [
      'https://images.unsplash.com/photo-1600271886742-f049cd451bba?w=400&h=400&fit=crop'
    ],
    rating: 4.5,
    vendorId: '2',
    vendor: mockVendors[1]
  },
  {
    id: '3',
    name: 'Rissol de Carne',
    price: 100,
    category: 'salgados',
    photos: [
      'https://images.unsplash.com/photo-1599490659213-e2b9527bd087?w=400&h=400&fit=crop'
    ],
    rating: 5,
    vendorId: '1',
    vendor: mockVendors[0]
  },
  {
    id: '4',
    name: 'Bolo de Chocolate',
    price: 250,
    category: 'doces',
    photos: [
      'https://images.unsplash.com/photo-1578985545062-69928b1d9587?w=400&h=400&fit=crop'
    ],
    rating: 5,
    vendorId: '3',
    vendor: mockVendors[2]
  },
  {
    id: '5',
    name: 'Água Mineral',
    price: 80,
    category: 'bebidas',
    photos: [
      'https://images.unsplash.com/photo-1548839140-29a749e1cf4d?w=400&h=400&fit=crop'
    ],
    rating: 4,
    vendorId: '2',
    vendor: mockVendors[1]
  },
  {
    id: '6',
    name: 'Empada de Frango',
    price: 120,
    category: 'salgados',
    photos: [
      'https://images.unsplash.com/photo-1619740455993-9e4daf3e15f6?w=400&h=400&fit=crop'
    ],
    rating: 4.5,
    vendorId: '3',
    vendor: mockVendors[2]
  },
  {
    id: '7',
    name: 'Pastel de Carne',
    price: 180,
    category: 'salgados',
    photos: [
      'https://images.unsplash.com/photo-1601050690597-df0568f70950?w=400&h=400&fit=crop'
    ],
    rating: 5,
    vendorId: '4',
    vendor: mockVendors[3]
  },
  {
    id: '8',
    name: 'Gelado de Morango',
    price: 150,
    category: 'gelados',
    photos: [
      'https://images.unsplash.com/photo-1488477181946-6428a0291777?w=400&h=400&fit=crop'
    ],
    rating: 5,
    vendorId: '5',
    vendor: mockVendors[4]
  },
  {
    id: '9',
    name: 'Refrigerante',
    price: 120,
    category: 'bebidas',
    photos: [
      'https://images.unsplash.com/photo-1581006852262-e4307cf6283a?w=400&h=400&fit=crop'
    ],
    rating: 4,
    vendorId: '6',
    vendor: mockVendors[5]
  },
  {
    id: '10',
    name: 'Brigadeiro',
    price: 50,
    category: 'doces',
    photos: [
      'https://images.unsplash.com/photo-1586985289688-ca3cf47d3e6e?w=400&h=400&fit=crop'
    ],
    rating: 5,
    vendorId: '4',
    vendor: mockVendors[3]
  },
  {
    id: '11',
    name: 'Coxinha',
    price: 150,
    category: 'salgados',
    photos: [
      'https://images.unsplash.com/photo-1601050690532-db4950f5c2f4?w=400&h=400&fit=crop'
    ],
    rating: 4.5,
    vendorId: '5',
    vendor: mockVendors[4]
  },
  {
    id: '12',
    name: 'Café',
    price: 100,
    category: 'bebidas',
    photos: [
      'https://images.unsplash.com/photo-1509042239860-f550ce710b93?w=400&h=400&fit=crop'
    ],
    rating: 4.5,
    vendorId: '6',
    vendor: mockVendors[5]
  }
];

export default function App() {
  const [selectedCategory, setSelectedCategory] = useState<string>('todos');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [selectedVendorId, setSelectedVendorId] = useState<string | null>(null);
  const [activeTab, setActiveTab] = useState<'products' | 'vendors'>('products');
  const [showAdmin, setShowAdmin] = useState<boolean>(false);
  const [vendors, setVendors] = useState<Vendor[]>(mockVendors);
  const [products, setProducts] = useState<Product[]>(mockProducts);

  // Load data from localStorage on mount
  useEffect(() => {
    const savedVendors = localStorage.getItem('levaaqui_vendors');
    const savedProducts = localStorage.getItem('levaaqui_products');
    
    if (savedVendors) {
      const parsedVendors = JSON.parse(savedVendors);
      setVendors(parsedVendors);
      
      // Update products with new vendor data
      if (savedProducts) {
        const parsedProducts = JSON.parse(savedProducts);
        const updatedProducts = parsedProducts.map((product: Product) => {
          const vendor = parsedVendors.find((v: Vendor) => v.id === product.vendorId);
          return vendor ? { ...product, vendor } : product;
        });
        setProducts(updatedProducts);
      }
    } else if (savedProducts) {
      setProducts(JSON.parse(savedProducts));
    }
  }, []);

  // Show Admin Panel
  if (showAdmin) {
    return <AdminPanel onBack={() => setShowAdmin(false)} />;
  }

  const categories = [
    'todos',
    'gelados',
    'bebidas',
    'salgados',
    'doces',
    'abaixo de 200kz'
  ];

  const filteredProducts = products.filter(product => {
    const matchesCategory = selectedCategory === 'todos' || 
      (selectedCategory === 'abaixo de 200kz' ? product.price < 200 : product.category === selectedCategory);
    
    const matchesSearch = searchQuery === '' ||
      product.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      product.vendor.name.toLowerCase().includes(searchQuery.toLowerCase());
    
    return matchesCategory && matchesSearch;
  });

  const handleVendorClick = (vendorId: string) => {
    setSelectedVendorId(vendorId);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleBackToHome = () => {
    setSelectedVendorId(null);
  };

  if (selectedVendorId) {
    const vendor = vendors.find(v => v.id === selectedVendorId);
    const vendorProducts = products.filter(p => p.vendorId === selectedVendorId);
    
    if (vendor) {
      return (
        <VendorPage
          vendor={vendor}
          products={vendorProducts}
          onBack={handleBackToHome}
        />
      );
    }
  }

  return (
    <div className="min-h-screen bg-gradient-to-b from-blue-50 to-yellow-50">
      <Header onAdminClick={() => setShowAdmin(true)} />
      
      <main>
        <Hero />
        
        <AboutSection />
        
        {/* Tab Navigation */}
        <TabNavigation activeTab={activeTab} onTabChange={setActiveTab} />

        {/* Products Section */}
        {activeTab === 'products' && (
          <section id="products" className="py-16 px-4 max-w-7xl mx-auto">
            <div className="text-center mb-12">
              <h2 className="text-4xl font-bold text-blue-900 mb-4">
                Produtos Disponíveis
              </h2>
              <p className="text-lg text-gray-600">
                Descubra os melhores produtos do campus
              </p>
            </div>

            <SearchBar
              searchQuery={searchQuery}
              onSearchChange={setSearchQuery}
            />

            <CategoryFilter
              categories={categories}
              selectedCategory={selectedCategory}
              onCategoryChange={setSelectedCategory}
            />

            <ProductGrid
              products={filteredProducts}
              onVendorClick={handleVendorClick}
            />
          </section>
        )}

        {/* Vendors Section */}
        {activeTab === 'vendors' && (
          <VendorListSection
            vendors={vendors}
            products={products}
            onVendorClick={handleVendorClick}
          />
        )}

        <LocationSection />
      </main>

      <Footer />
    </div>
  );
}